function ver = hdrvdp_version()

ver = 2.21;

end